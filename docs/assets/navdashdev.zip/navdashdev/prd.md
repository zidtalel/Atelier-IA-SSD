# Product Requirements Document (PRD) - NavDash

**Projet** : navdash (com.bdeb.navdash)  
**Version** : 1.0  
**Date** : 4 janvier 2026  
**Product Owner** : Équipe NavDash  
**Objectif** : Tableau de Bord de Diagnostic de l'Expérience Utilisateur en Temps Réel

---

## 1. Vue d'Ensemble du Produit

### 1.1 Description
NavDash est une application web Spring Boot qui fournit un **tableau de bord en temps réel** permettant aux utilisateurs de diagnostiquer leur expérience de navigation. L'application exploite les APIs natives du navigateur pour collecter et afficher des métriques de performance, tout en permettant aux utilisateurs de configurer des seuils d'alerte personnalisés.

### 1.2 Objectifs Produit
- Offrir une visibilité immédiate sur les conditions de navigation de l'utilisateur
- Permettre la configuration de seuils d'alerte personnalisés
- Détecter et signaler automatiquement les conditions critiques
- Persister les préférences utilisateur pour une expérience continue

### 1.3 Utilisateurs Cibles
- Développeurs web testant leurs applications
- Équipes de support technique diagnostiquant des problèmes clients
- Utilisateurs finaux souhaitant comprendre leur expérience de navigation

---

## 2. Fonctionnalités Principales

### 2.1 Affichage des Métriques en Temps Réel (Lecture Seule)

#### 2.1.1 Vitesse Réseau
**Description** : Affichage de la bande passante estimée du réseau utilisateur  
**Source de Données** : `navigator.connection.effectiveType` (Network Information API)  
**Valeurs Possibles** : 
- `4G` (Connexion rapide)
- `3G` (Connexion moyenne)
- `slow-3G` (Connexion lente)
- `2G` (Connexion très lente)
- `slow-2G` (Connexion extrêmement lente)

**Affichage** :
```
Vitesse Réseau : 4G
```

**Attribut QA** : `data-cy="display-network-speed"`

---

#### 2.1.2 État de la Batterie
**Description** : Affichage du niveau de charge et de l'état de recharge  
**Source de Données** : Battery Status API (`navigator.getBattery()`)

**Métriques** :
- **Niveau de charge** : Pourcentage de 0% à 100%
- **État de charge** : "Branché" ou "Débranché"

**Affichage** :
```
Batterie : 85% (Branché)
Batterie : 42% (Débranché)
```

**Attributs QA** :
- Niveau : `data-cy="display-battery-level"`
- État : `data-cy="display-battery-status"`

---

#### 2.1.3 Cœurs Logiques du Processeur
**Description** : Affichage du nombre de cœurs CPU logiques  
**Source de Données** : `navigator.hardwareConcurrency`  
**Caractéristique** : Valeur statique (ne change pas pendant la session)

**Affichage** :
```
Cœurs CPU : 8
```

**Attribut QA** : `data-cy="display-cpu-cores"`

---

#### 2.1.4 Résolution d'Écran
**Description** : Affichage de la largeur et hauteur du viewport  
**Source de Données** : `window.innerWidth` et `window.innerHeight`  
**Mise à jour** : Dynamique lors du redimensionnement de la fenêtre

**Affichage** :
```
Résolution : 1920 x 1080
```

**Attribut QA** : `data-cy="display-screen-resolution"`

---

#### 2.1.5 Latence de Chargement
**Description** : Temps de chargement de la page en millisecondes  
**Source de Données** : Performance API (`DOMContentLoaded` ou équivalent)  
**Unité** : Millisecondes (ms)

**Affichage** :
```
Latence de Chargement : 1250 ms
```

**Attribut QA** : `data-cy="display-page-latency"`

---

### 2.2 Formulaire "Profil de Diagnostic"

#### 2.2.1 Champs du Formulaire

##### Nom et Prénom
- **Type** : Texte
- **Obligatoire** : Oui
- **Longueur Max** : 50 caractères
- **Validation** : Champ non vide
- **Attribut QA** : 
  - Nom : `data-cy="input-lastname-profile"`
  - Prénom : `data-cy="input-firstname-profile"`

##### Email
- **Type** : Email
- **Obligatoire** : Oui
- **Format** : Validation email standard (RFC 5322)
- **Exemple** : `utilisateur@example.com`
- **Attribut QA** : `data-cy="input-email-profile"`
- **Message d'erreur** : "Format d'email invalide"

##### Type d'Abonnement
- **Type** : Liste déroulante (select)
- **Obligatoire** : Oui
- **Valeurs** :
  1. `Basique`
  2. `Premium`
  3. `Support Dédié`
- **Valeur par défaut** : Aucune (sélection requise)
- **Attribut QA** : `data-cy="select-subscription-type"`

##### Seuil de Latence (ms)
- **Type** : Numérique (number)
- **Obligatoire** : Oui
- **Valeur Min** : 100 ms
- **Valeur Max** : 5000 ms
- **Incrément** : 50 ms (recommandé)
- **Valeur Suggérée** : 2000 ms
- **Attribut QA** : `data-cy="input-latency-threshold"`
- **Message d'erreur** : "Le seuil doit être entre 100 et 5000 ms"

##### Seuil de Qualité Réseau
- **Type** : Liste déroulante (select)
- **Obligatoire** : Oui
- **Description** : Connexion minimum tolérée par l'utilisateur
- **Valeurs** :
  1. `3G` (Tolérance haute)
  2. `slow-3G` (Tolérance moyenne)
  3. `2G` (Tolérance basse)
- **Valeur par défaut** : `3G`
- **Attribut QA** : `data-cy="select-network-threshold"`

#### 2.2.2 Actions du Formulaire

##### Bouton Enregistrer
- **Libellé** : "Enregistrer le Profil"
- **Type** : Submit
- **Comportement** : Valide et sauvegarde les préférences utilisateur
- **Attribut QA** : `data-cy="btn-save-profile"`

##### Bouton Réinitialiser
- **Libellé** : "Réinitialiser"
- **Type** : Reset
- **Comportement** : Vide tous les champs du formulaire
- **Attribut QA** : `data-cy="btn-reset-profile"`

---

## 3. Règles Métier et Comportements Conditionnels

### 3.1 Validation de l'Email

**Règle** : L'enregistrement du profil est **bloqué** si le format de l'email est invalide.

**Comportement** :
- Validation côté client (HTML5 + JavaScript)
- Validation côté serveur (Spring Boot)
- Affichage d'un message d'erreur : "Format d'email invalide"
- Le bouton "Enregistrer" déclenche la validation avant soumission

**Message d'erreur** :
- **Attribut QA** : `data-cy="msg-error-email-invalid"`

---

### 3.2 Champ Conditionnel : Motif de la Lenteur

**Condition de Déclenchement** :  
Si la **Vitesse Réseau** en temps réel est **inférieure ou égale** au **Seuil de Qualité Réseau** défini par l'utilisateur, alors :

**Comportement** :
1. Un nouveau champ textuel **"Motif de la Lenteur"** apparaît dynamiquement
2. Ce champ devient **obligatoire** pour l'enregistrement du profil
3. Le champ disparaît si la condition n'est plus remplie

**Spécifications du Champ** :
- **Type** : Textarea
- **Obligatoire** : Oui (quand visible)
- **Longueur Max** : 500 caractères
- **Placeholder** : "Expliquez pourquoi vous continuez malgré la connexion lente..."
- **Attribut QA** : `data-cy="textarea-slow-network-reason"`

**Exemple de Scénario** :
- Seuil défini : `3G`
- Vitesse réelle : `slow-3G` → Champ affiché
- Vitesse réelle : `4G` → Champ masqué

---

### 3.3 Alerte Critique de Latence

**Condition de Déclenchement** :  
Si la **Latence de Chargement** réelle mesurée **dépasse** le **Seuil de Latence** défini par l'utilisateur.

**Comportement** :
1. Afficher un **Bandeau d'Alerte Rouge** en haut de la page
2. Le bandeau reste affiché **tant que la condition est vraie**
3. Le bandeau disparaît automatiquement si la latence repasse sous le seuil

**Spécifications du Bandeau** :
- **Position** : Fixe en haut de l'écran (sticky)
- **Couleur** : Rouge (#dc3545 ou équivalent)
- **Icône** : ⚠️ (warning icon)
- **Message** : "ALERTE : La latence de chargement ({valeur} ms) dépasse votre seuil de {seuil} ms"
- **Attribut QA** : `data-cy="alert-latency-exceeded"`

**Exemple** :
```
⚠️ ALERTE : La latence de chargement (2500 ms) dépasse votre seuil de 2000 ms
```

---

### 3.4 Désactivation du Formulaire (Conditions d'Urgence)

**Conditions de Désactivation** :  
Le formulaire de saisie passe en **mode lecture seule** (disabled) si **AU MOINS UNE** des conditions suivantes est remplie :

#### Condition 1 : Batterie Critique
- **Critère** : Niveau de batterie < 10% **ET** appareil non branché
- **Indicateur visuel** : Badge "Mode Batterie Critique"
- **Attribut QA** : `data-cy="badge-battery-critical"`

#### Condition 2 : Écran Mobile
- **Critère** : Largeur du viewport < 768px
- **Indicateur visuel** : Badge "Mode Mobile Détecté"
- **Attribut QA** : `data-cy="badge-mobile-mode"`

**Comportement** :
- Tous les champs de saisie sont désactivés (`disabled="disabled"`)
- Le bouton "Enregistrer" est désactivé
- Un message explicatif est affiché au-dessus du formulaire
- Le formulaire redevient actif dès que la condition n'est plus remplie

**Message Explicatif** :
- **Batterie Critique** : "Le formulaire est désactivé pour préserver la batterie (< 10%). Veuillez brancher votre appareil."
  - **Attribut QA** : `data-cy="msg-form-disabled-battery"`
- **Mode Mobile** : "Le formulaire est désactivé en mode mobile (écran < 768px). Utilisez un écran plus large pour modifier vos préférences."
  - **Attribut QA** : `data-cy="msg-form-disabled-mobile"`

---

## 4. Persistance des Données

### 4.1 Local Storage (Navigateur)

**Données Persistées** :
- Nom et Prénom
- Email
- Type d'Abonnement
- Seuil de Latence (ms)
- Seuil de Qualité Réseau

**Format** : JSON (via Gson côté serveur, via JavaScript côté client)

**Clé de Stockage** : `navdash.userProfile`

**Exemple de Structure JSON** :
```json
{
  "lastName": "Dupont",
  "firstName": "Marie",
  "email": "marie.dupont@example.com",
  "subscriptionType": "Premium",
  "latencyThreshold": 1500,
  "networkQualityThreshold": "3G"
}
```

**Comportement** :
- Sauvegarde automatique après validation du formulaire
- Chargement automatique au démarrage de l'application
- Mise à jour en temps réel lors de modifications

---

### 4.2 Pas de Persistance Serveur

**Note Importante** : Les préférences utilisateur ne sont **pas** sauvegardées côté serveur dans cette version. Elles sont uniquement stockées dans le Local Storage du navigateur.

---

## 5. Exigences Non-Fonctionnelles

### 5.1 Performance

#### 5.1.1 Mise à Jour des Métriques
- **Fréquence** : Toutes les 2 secondes maximum
- **Optimisation** : Éviter les re-rendus inutiles du DOM
- **Technique** : Utiliser des événements natifs (`change`, `chargingchange`) plutôt que du polling intensif

#### 5.1.2 Temps de Chargement Initial
- **Objectif** : < 2 secondes sur connexion 3G
- **Mesure** : Via Performance API

---

### 5.2 Configuration Serveur

#### Port d'Écoute
- **Port Obligatoire** : **8087**
- **Raison** : Éviter le conflit avec le port 8080 par défaut, souvent occupé
- **Configuration** : `application.properties` → `server.port=8087`

**Fichier de Configuration** :
```properties
# application.properties
server.port=8087
```

---

### 5.3 Compatibilité Navigateur

**Navigateurs Supportés** :
- Google Chrome 90+
- Mozilla Firefox 88+
- Microsoft Edge 90+
- Safari 14+ (support limité des APIs de batterie)

**APIs Requises** :
- Network Information API
- Battery Status API
- Performance API
- Local Storage API

**Gestion des APIs Non Supportées** :
- Détecter la disponibilité de chaque API
- Afficher un message de substitution si l'API n'est pas disponible
- Exemple : "Batterie : Non supportée sur ce navigateur"

---

### 5.4 Accessibilité

**Standards** :
- Conformité WCAG 2.1 Niveau AA (recommandé)
- Labels ARIA pour les éléments dynamiques
- Support de la navigation au clavier

**Éléments Critiques** :
- Les alertes doivent avoir `role="alert"`
- Les champs obligatoires doivent avoir `aria-required="true"`
- Les messages d'erreur doivent être associés aux champs via `aria-describedby`

---

### 5.5 Sécurité

**Validation des Entrées** :
- Validation côté client **ET** côté serveur
- Échappement des caractères spéciaux (protection XSS)
- Limitation de la longueur des champs

**Headers de Sécurité** :
- Content-Security-Policy
- X-Frame-Options
- X-Content-Type-Options

---

## 6. User Stories

### US-001 : Visualisation des Métriques en Temps Réel
**En tant qu'** utilisateur  
**Je veux** voir mes métriques de navigation en temps réel  
**Afin de** comprendre les conditions actuelles de mon environnement

**Critères d'Acceptation** :
- [ ] La vitesse réseau s'affiche et se met à jour automatiquement
- [ ] Le niveau de batterie et l'état de charge sont visibles
- [ ] Le nombre de cœurs CPU est affiché
- [ ] La résolution d'écran est affichée et se met à jour lors du redimensionnement
- [ ] La latence de chargement est mesurée et affichée

---

### US-002 : Configuration des Seuils d'Alerte
**En tant qu'** utilisateur  
**Je veux** configurer mes propres seuils d'alerte  
**Afin de** recevoir des notifications adaptées à mes besoins

**Critères d'Acceptation** :
- [ ] Je peux définir un seuil de latence entre 100 et 5000 ms
- [ ] Je peux sélectionner un seuil de qualité réseau (3G, slow-3G, 2G)
- [ ] Mes préférences sont sauvegardées dans le Local Storage
- [ ] Mes préférences sont rechargées automatiquement à la prochaine visite

---

### US-003 : Alerte de Latence Critique
**En tant qu'** utilisateur  
**Je veux** être alerté visuellement quand la latence dépasse mon seuil  
**Afin de** prendre des mesures correctives

**Critères d'Acceptation** :
- [ ] Un bandeau rouge apparaît en haut de la page quand le seuil est dépassé
- [ ] Le bandeau affiche la latence actuelle et mon seuil configuré
- [ ] Le bandeau disparaît automatiquement quand la latence redevient acceptable

---

### US-004 : Champ Conditionnel pour Connexion Lente
**En tant qu'** utilisateur ayant une connexion lente  
**Je veux** expliquer pourquoi je continue à utiliser l'application  
**Afin que** l'équipe comprenne mon cas d'usage

**Critères d'Acceptation** :
- [ ] Un champ "Motif de la Lenteur" apparaît quand ma connexion est trop lente
- [ ] Le champ est obligatoire pour enregistrer mon profil
- [ ] Le champ disparaît si ma connexion s'améliore

---

### US-005 : Protection en Cas de Batterie Critique
**En tant qu'** utilisateur avec une batterie faible  
**Je veux** que le formulaire soit désactivé  
**Afin de** préserver ma batterie restante

**Critères d'Acceptation** :
- [ ] Le formulaire se désactive automatiquement si batterie < 10% et non branché
- [ ] Un message explicatif est affiché
- [ ] Le formulaire se réactive automatiquement quand l'appareil est branché

---

### US-006 : Adaptation au Mode Mobile
**En tant qu'** utilisateur mobile  
**Je veux** que le formulaire soit désactivé sur petit écran  
**Afin de** être encouragé à utiliser un écran plus adapté

**Critères d'Acceptation** :
- [ ] Le formulaire se désactive si la largeur du viewport < 768px
- [ ] Un message explicatif est affiché
- [ ] Le formulaire se réactive si l'écran est redimensionné au-dessus de 768px

---

## 7. Wireframes et Maquettes (Description Textuelle)

### 7.1 Structure de la Page

```
┌─────────────────────────────────────────────────────────────┐
│ [BANDEAU D'ALERTE ROUGE - conditionnel]                     │
│ ⚠️ ALERTE : La latence (2500 ms) dépasse votre seuil        │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                    NAVDASH - DIAGNOSTIC                      │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ MÉTRIQUES EN TEMPS RÉEL                                      │
├─────────────────────────────────────────────────────────────┤
│ Vitesse Réseau    : 4G                                       │
│ Batterie          : 85% (Branché)                            │
│ Cœurs CPU         : 8                                        │
│ Résolution        : 1920 x 1080                              │
│ Latence Chargement: 1250 ms                                  │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ PROFIL DE DIAGNOSTIC                                         │
├─────────────────────────────────────────────────────────────┤
│ [MESSAGE DÉSACTIVATION - conditionnel]                       │
│                                                              │
│ Nom              : [_____________________________]           │
│ Prénom           : [_____________________________]           │
│ Email            : [_____________________________]           │
│ Type d'Abonnement: [▼ Sélectionner              ]           │
│ Seuil Latence    : [____] ms (100-5000)                     │
│ Seuil Réseau     : [▼ 3G                        ]           │
│                                                              │
│ [CHAMP CONDITIONNEL : Motif de la Lenteur]                  │
│ [                                            ]               │
│ [                                            ]               │
│                                                              │
│ [Enregistrer le Profil]  [Réinitialiser]                    │
└─────────────────────────────────────────────────────────────┘
```

---

## 8. Scénarios de Test Clés

### Scénario 1 : Soumission Valide du Profil
**Prérequis** : Formulaire actif, tous les champs remplis correctement  
**Actions** :
1. Remplir Nom : "Dupont"
2. Remplir Prénom : "Marie"
3. Remplir Email : "marie.dupont@example.com"
4. Sélectionner Abonnement : "Premium"
5. Définir Seuil Latence : 2000 ms
6. Sélectionner Seuil Réseau : "3G"
7. Cliquer sur "Enregistrer le Profil"

**Résultat Attendu** :
- Message de succès affiché
- Données sauvegardées dans Local Storage
- Formulaire reste rempli avec les données

---

### Scénario 2 : Validation Email Invalide
**Actions** :
1. Remplir Email : "email-invalide"
2. Tenter de soumettre le formulaire

**Résultat Attendu** :
- Message d'erreur : "Format d'email invalide"
- Soumission bloquée
- Focus revient sur le champ Email

---

### Scénario 3 : Apparition du Champ Conditionnel
**Prérequis** : Seuil Réseau défini à "3G"  
**Actions** :
1. Simuler une connexion "slow-3G"

**Résultat Attendu** :
- Le champ "Motif de la Lenteur" apparaît
- Le champ est marqué comme obligatoire
- La soumission échoue si le champ est vide

---

### Scénario 4 : Déclenchement de l'Alerte Latence
**Prérequis** : Seuil Latence défini à 1500 ms  
**Actions** :
1. Charger la page avec une latence de 2000 ms

**Résultat Attendu** :
- Bandeau rouge affiché en haut de la page
- Message : "ALERTE : La latence (2000 ms) dépasse votre seuil de 1500 ms"
- Bandeau reste visible tant que la latence > 1500 ms

---

### Scénario 5 : Désactivation pour Batterie Critique
**Actions** :
1. Simuler batterie à 8% et non branché

**Résultat Attendu** :
- Formulaire désactivé (tous les champs en lecture seule)
- Message affiché : "Le formulaire est désactivé pour préserver la batterie..."
- Badge "Mode Batterie Critique" visible

---

### Scénario 6 : Désactivation en Mode Mobile
**Actions** :
1. Redimensionner le viewport à 600px de large

**Résultat Attendu** :
- Formulaire désactivé
- Message affiché : "Le formulaire est désactivé en mode mobile..."
- Badge "Mode Mobile Détecté" visible

---

## 9. Attributs data-cy pour l'Automatisation QA

### Récapitulatif Complet des Sélecteurs Cypress

#### Métriques en Temps Réel
| Élément | Attribut data-cy |
|---------|------------------|
| Vitesse Réseau | `display-network-speed` |
| Niveau Batterie | `display-battery-level` |
| État Batterie | `display-battery-status` |
| Cœurs CPU | `display-cpu-cores` |
| Résolution Écran | `display-screen-resolution` |
| Latence Chargement | `display-page-latency` |

#### Formulaire Profil
| Élément | Attribut data-cy |
|---------|------------------|
| Champ Nom | `input-lastname-profile` |
| Champ Prénom | `input-firstname-profile` |
| Champ Email | `input-email-profile` |
| Select Abonnement | `select-subscription-type` |
| Champ Seuil Latence | `input-latency-threshold` |
| Select Seuil Réseau | `select-network-threshold` |
| Textarea Motif Lenteur | `textarea-slow-network-reason` |
| Bouton Enregistrer | `btn-save-profile` |
| Bouton Réinitialiser | `btn-reset-profile` |

#### Alertes et Messages
| Élément | Attribut data-cy |
|---------|------------------|
| Bandeau Alerte Latence | `alert-latency-exceeded` |
| Badge Batterie Critique | `badge-battery-critical` |
| Badge Mode Mobile | `badge-mobile-mode` |
| Message Erreur Email | `msg-error-email-invalid` |
| Message Formulaire Désactivé (Batterie) | `msg-form-disabled-battery` |
| Message Formulaire Désactivé (Mobile) | `msg-form-disabled-mobile` |
| Message Succès Enregistrement | `msg-success-profile-saved` |

---

## 10. Critères de Succès du Produit

### Critères Fonctionnels
- ✅ Toutes les métriques s'affichent correctement sur les navigateurs supportés
- ✅ Les seuils configurés déclenchent les comportements conditionnels attendus
- ✅ Les préférences sont persistées et rechargées correctement
- ✅ Le formulaire se désactive dans les conditions d'urgence définies

### Critères de Performance
- ✅ Temps de chargement initial < 2 secondes (3G)
- ✅ Mise à jour des métriques sans dégradation perceptible
- ✅ Pas de fuite mémoire sur session prolongée (> 1 heure)

### Critères de Qualité
- ✅ 100% des éléments interactifs ont un attribut `data-cy`
- ✅ Validation côté client ET serveur pour tous les champs
- ✅ Tests E2E Cypress couvrant tous les scénarios critiques

---

## 11. Hors Périmètre (Version 1.0)

**Fonctionnalités NON Incluses** :
- ❌ Authentification utilisateur multi-comptes
- ❌ Historique des métriques sur plusieurs sessions
- ❌ Notifications push ou email
- ❌ Dashboard administrateur
- ❌ Export des données en CSV/PDF
- ❌ Support multilingue
- ❌ Mode sombre (Dark Mode)
- ❌ Intégration avec des APIs tierces (analytics, monitoring)

---

## 12. Dépendances et Risques

### Dépendances Techniques
- **APIs Navigateur** : Dépendance aux APIs natives (batterie, connexion)
- **Local Storage** : Limitation à ~5-10 MB par domaine
- **Compatibilité** : Safari a un support limité de Battery Status API

### Risques Identifiés
| Risque | Probabilité | Impact | Mitigation |
|--------|-------------|--------|------------|
| API Batterie non supportée sur Safari | Haute | Moyen | Afficher un message de substitution |
| Local Storage plein | Faible | Faible | Limiter la taille des données stockées |
| Performance sur vieux navigateurs | Moyenne | Moyen | Définir des navigateurs minimums supportés |

---

## 13. Prochaines Étapes (Roadmap Future)

### Version 1.1 (Q2 2026)
- Support du mode sombre
- Historique des 10 dernières sessions
- Export des données en JSON

### Version 2.0 (Q3 2026)
- Authentification utilisateur
- Dashboard multi-utilisateurs
- Notifications en temps réel (WebSocket)

---

**Approuvé par** : Product Owner NavDash  
**Date d'approbation** : 4 janvier 2026  
**Prochaine révision** : Mars 2026
