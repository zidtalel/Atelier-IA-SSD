# Instructions Techniques - Projet navdash

**Projet** : navdash (com.bdeb.navdash)  
**Stack** : Java 17, Spring Boot 2.7.18, Thymeleaf, WebSocket, JUnit 5  
**Date de création** : 4 janvier 2026  
**Objectif** : Document de référence technique pour tous les développements assistés par IA

---

## 1. Architecture Générale

### 1.1 Structure du Projet
Le projet suit l'architecture **Spring Boot MVC** avec séparation stricte des responsabilités :

```
src/main/java/com/bdeb/navdash/
├── controller/     # Contrôleurs Spring MVC et REST
├── service/        # Logique métier
├── repository/     # Accès aux données (persistance simulée)
├── model/          # Entités et objets métier
├── dto/            # Data Transfer Objects
├── config/         # Configuration Spring (WebSocket, etc.)
└── App.java        # Point d'entrée de l'application
```

### 1.2 Principes Architecturaux
- **Séparation des couches** : Controller → Service → Repository
- **Injection de dépendances** : Utiliser `@Autowired` ou l'injection par constructeur (préférée)
- **Single Responsibility** : Chaque classe a une responsabilité unique et bien définie
- **Interface-based design** : Les Services doivent implémenter des interfaces

---

## 2. Conventions de Nommage

### 2.1 Classes et Interfaces
- **Classes** : `PascalCase`
  - Contrôleurs : `*Controller` (ex: `UserController`, `NavigationController`)
  - Services : `*Service` (ex: `GeolocationService`, `UserPreferenceService`)
  - Repositories : `*Repository` (ex: `UserRepository`, `PreferenceRepository`)
  - DTOs : `*DTO` ou `*Request`/`*Response` (ex: `UserDTO`, `LoginRequest`)
  - Entités : Nom du domaine (ex: `User`, `Location`, `Preference`)

### 2.2 Méthodes et Variables
- **Méthodes** : `camelCase` avec verbe d'action
  - Lecture : `getUser()`, `findAllUsers()`, `isConnected()`
  - Écriture : `saveUser()`, `updatePreferences()`, `deleteUser()`
  - Business : `calculateDistance()`, `processLocation()`
  
- **Variables** : `camelCase`
  - Variables locales : `userId`, `currentLocation`, `isActive`
  - Constantes : `UPPER_SNAKE_CASE` (ex: `MAX_RETRY_ATTEMPTS`, `DEFAULT_TIMEOUT`)

### 2.3 Packages
- Noms en minuscules, sans underscore : `controller`, `service`, `repository`

---

## 3. Gestion des Données (Backend)

### 3.1 Sérialisation avec Gson
- **Bibliothèque obligatoire** : Gson (déjà inclus dans `pom.xml`)
- **Usage** : Sérialisation/désérialisation JSON pour les DTOs et préférences utilisateur

**Exemple de sérialisation** :
```java
import com.google.gson.Gson;

public class PreferenceService {
    private final Gson gson = new Gson();
    
    public String serializePreferences(UserPreferencesDTO preferences) {
        return gson.toJson(preferences);
    }
    
    public UserPreferencesDTO deserializePreferences(String json) {
        return gson.fromJson(json, UserPreferencesDTO.class);
    }
}
```

### 3.2 Couche Service
- **Toute logique métier** doit être dans un Service
- **Transactions simulées** : Les Services gèrent la cohérence des données
- **Validation** : Les Services valident les données avant persistance

**Pattern obligatoire** :
```java
public interface UserService {
    UserDTO findById(Long id);
    UserDTO save(UserDTO user);
    void delete(Long id);
}

@Service
public class UserServiceImpl implements UserService {
    // Implémentation
}
```

### 3.3 Couche Repository
- Interface de persistance (même pour simulation)
- Retourne des entités métier, pas des DTOs
- Conversion entité ↔ DTO se fait dans le Service

---

## 4. Contrôleurs Spring MVC

### 4.1 Annotations
- `@Controller` : Pour les contrôleurs retournant des vues Thymeleaf
- `@RestController` : Pour les APIs REST (JSON)
- `@RequestMapping` : Définir le chemin de base
- `@GetMapping`, `@PostMapping`, etc. : Pour les endpoints

### 4.2 Gestion des Requêtes
```java
@Controller
@RequestMapping("/users")
public class UserController {
    
    @Autowired
    private UserService userService;
    
    @GetMapping("/{id}")
    public String showUser(@PathVariable Long id, Model model) {
        UserDTO user = userService.findById(id);
        model.addAttribute("user", user);
        return "user-detail"; // Template Thymeleaf
    }
    
    @PostMapping("/save")
    public String saveUser(@ModelAttribute UserDTO userDTO) {
        userService.save(userDTO);
        return "redirect:/users";
    }
}
```

---

## 5. Templates Thymeleaf et Frontend

### 5.1 Syntaxe Thymeleaf Obligatoire
- **Attributs Thymeleaf** : `th:object`, `th:field`, `th:action`, `th:text`, `th:href`
- **Binding de formulaires** : Toujours utiliser `th:object` et `th:field`

**Exemple de formulaire** :
```html
<form th:action="@{/users/save}" th:object="${user}" method="post">
    <input type="text" th:field="*{firstName}" data-cy="input-firstname" />
    <input type="email" th:field="*{email}" data-cy="input-email" />
    <button type="submit" data-cy="btn-submit-user">Enregistrer</button>
</form>
```

### 5.2 JavaScript
- **Pas de JavaScript inline** : Tout le code JS doit être externalisé
- **Fichiers séparés** : Placer dans `src/main/resources/static/js/`
- **APIs natives** : Géolocalisation, Connexion réseau, WebSocket en fichiers dédiés

**Structure recommandée** :
```
src/main/resources/
├── static/
│   ├── js/
│   │   ├── geolocation.js
│   │   ├── network.js
│   │   └── websocket-client.js
│   └── css/
└── templates/
```

---

## 6. Standards d'Automatisation QA (CRITIQUE)

### 6.1 Attribut data-cy Obligatoire
**RÈGLE ABSOLUE** : Tous les éléments interactifs et d'affichage critique doivent avoir un attribut `data-cy` unique.

### 6.2 Éléments Concernés
- ✅ Boutons (`<button>`, `<input type="submit">`)
- ✅ Champs de formulaire (`<input>`, `<textarea>`, `<select>`)
- ✅ Liens de navigation (`<a>`)
- ✅ Éléments affichant des métriques (distance, vitesse, statut)
- ✅ Messages d'erreur et de confirmation
- ✅ Modales et dialogues

### 6.3 Convention de Nommage data-cy
Format : `{type}-{description}-{contexte}`

**Exemples** :
```html
<!-- Formulaires -->
<input type="email" th:field="*{email}" data-cy="input-email-login" />
<input type="password" th:field="*{password}" data-cy="input-password-login" />
<select th:field="*{country}" data-cy="select-country-profile">

<!-- Boutons -->
<button type="submit" data-cy="btn-submit-login">Connexion</button>
<button type="button" data-cy="btn-cancel-edit">Annuler</button>

<!-- Navigation -->
<a th:href="@{/dashboard}" data-cy="link-dashboard">Tableau de bord</a>

<!-- Affichage de données -->
<span th:text="${currentSpeed}" data-cy="display-speed-current"></span>
<div class="status" data-cy="display-connection-status">Connecté</div>

<!-- Messages -->
<div class="alert alert-success" data-cy="msg-success-save">Enregistré</div>
<div class="error" data-cy="msg-error-validation">Erreur de validation</div>
```

### 6.4 Génération Automatique
Lors de la génération de templates HTML, l'IA doit **systématiquement** ajouter les `data-cy` selon ces règles.

---

## 7. Logging avec SLF4J

### 7.1 Règles de Logging
- **Interdiction stricte** : `System.out.println()` et `System.err.println()`
- **Bibliothèque obligatoire** : SLF4J (façade)
- **Niveaux de log** : TRACE, DEBUG, INFO, WARN, ERROR

### 7.2 Implémentation
```java
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class UserServiceImpl implements UserService {
    
    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
    
    @Override
    public UserDTO findById(Long id) {
        logger.debug("Recherche de l'utilisateur avec ID: {}", id);
        
        UserDTO user = repository.findById(id);
        
        if (user == null) {
            logger.warn("Aucun utilisateur trouvé pour l'ID: {}", id);
        } else {
            logger.info("Utilisateur trouvé: {}", user.getEmail());
        }
        
        return user;
    }
}
```

### 7.3 Niveaux de Log Recommandés
- **DEBUG** : Flux d'exécution, entrée/sortie de méthodes
- **INFO** : Événements métier importants (création user, connexion)
- **WARN** : Situations anormales non bloquantes
- **ERROR** : Erreurs nécessitant une attention (exceptions)

---

## 8. Tests Unitaires (JUnit 5)

### 8.1 Structure des Tests
```
src/test/java/com/bdeb/navdash/
├── controller/
├── service/
└── repository/
```

### 8.2 Conventions
- Nom de classe : `*Test` (ex: `UserServiceTest`)
- Annotations : `@Test`, `@BeforeEach`, `@AfterEach`
- Assertions : Utiliser les assertions JUnit 5

**Exemple** :
```java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UserServiceTest {
    
    @Test
    void shouldFindUserById() {
        // Given
        Long userId = 1L;
        
        // When
        UserDTO user = userService.findById(userId);
        
        // Then
        assertNotNull(user);
        assertEquals(userId, user.getId());
    }
}
```

---

## 9. Configuration Spring Boot

### 9.1 Fichiers de Configuration
- `application.properties` ou `application.yml` : Configuration principale
- Profils : `application-{profile}.properties` (dev, test, prod)

### 9.2 WebSocket (si utilisé)
```java
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {
    
    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.enableSimpleBroker("/topic");
        config.setApplicationDestinationPrefixes("/app");
    }
    
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws").withSockJS();
    }
}
```

---

## 10. Checklist de Génération de Code par IA

Avant de valider toute génération de code, vérifier :

### Backend Java
- [ ] Nommage en `PascalCase` pour les classes
- [ ] Nommage en `camelCase` pour méthodes/variables
- [ ] Architecture MVC respectée (Controller → Service → Repository)
- [ ] Logger SLF4J utilisé (pas de `System.out`)
- [ ] Gson utilisé pour JSON (si applicable)
- [ ] Interfaces définies pour les Services

### Frontend Thymeleaf
- [ ] Attributs Thymeleaf utilisés (`th:*`)
- [ ] **Tous les éléments interactifs ont un `data-cy`**
- [ ] Pas de JavaScript inline
- [ ] Formulaires avec `th:object` et `th:field`

### Tests
- [ ] Tests JUnit 5 créés
- [ ] Nommage `*Test`
- [ ] Couverture des cas principaux

---

## 11. Exemples Complets

### 11.1 Contrôleur REST avec Validation
```java
@RestController
@RequestMapping("/api/preferences")
public class PreferenceController {
    
    private static final Logger logger = LoggerFactory.getLogger(PreferenceController.class);
    
    @Autowired
    private PreferenceService preferenceService;
    
    @GetMapping("/{userId}")
    public ResponseEntity<PreferenceDTO> getUserPreferences(@PathVariable Long userId) {
        logger.info("Récupération des préférences pour l'utilisateur: {}", userId);
        
        PreferenceDTO preferences = preferenceService.getPreferences(userId);
        return ResponseEntity.ok(preferences);
    }
    
    @PostMapping("/save")
    public ResponseEntity<String> savePreferences(@RequestBody PreferenceDTO dto) {
        logger.debug("Sauvegarde des préférences: {}", dto);
        
        preferenceService.save(dto);
        return ResponseEntity.ok("Préférences enregistrées");
    }
}
```

### 11.2 Template Thymeleaf avec data-cy
```html
<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org">
<head>
    <title>Profil Utilisateur</title>
</head>
<body>
    <h1 data-cy="heading-profile">Profil</h1>
    
    <form th:action="@{/users/update}" th:object="${user}" method="post">
        <div>
            <label for="firstName">Prénom</label>
            <input type="text" 
                   id="firstName" 
                   th:field="*{firstName}" 
                   data-cy="input-firstname-profile" />
        </div>
        
        <div>
            <label for="email">Email</label>
            <input type="email" 
                   id="email" 
                   th:field="*{email}" 
                   data-cy="input-email-profile" />
        </div>
        
        <div>
            <button type="submit" data-cy="btn-save-profile">Enregistrer</button>
            <a th:href="@{/dashboard}" data-cy="link-cancel-profile">Annuler</a>
        </div>
    </form>
    
    <div th:if="${message}" 
         class="success" 
         data-cy="msg-success-profile" 
         th:text="${message}"></div>
</body>
</html>
```

---

## 12. Ressources et Documentation

- **Spring Boot 2.7.x** : https://docs.spring.io/spring-boot/docs/2.7.x/reference/html/
- **Thymeleaf** : https://www.thymeleaf.org/documentation.html
- **Gson** : https://github.com/google/gson
- **SLF4J** : https://www.slf4j.org/manual.html
- **Cypress** : https://docs.cypress.io/

---

**Version** : 1.0  
**Dernière mise à jour** : 4 janvier 2026  
**Mainteneur** : Équipe navdash
