/**
 * NavDash - Main JavaScript
 * Gestion des métriques live et logiques conditionnelles
 * Conforme aux spécifications PRD et instructions.md
 */

(function() {
    'use strict';

    // ========== CONSTANTES ==========
    const LOCAL_STORAGE_KEY = 'navdash.userProfile';
    const BATTERY_UPDATE_INTERVAL = 10000; // 10 secondes
    const METRICS_CHECK_INTERVAL = 2000; // 2 secondes
    
    // Ordre de qualité réseau (du meilleur au pire)
    const NETWORK_QUALITY_ORDER = {
        '4g': 0,
        '3g': 1,
        'slow-3g': 2,
        '2g': 3,
        'slow-2g': 4
    };

    // ========== ÉTAT GLOBAL ==========
    const state = {
        metrics: {
            networkSpeed: null,
            batteryLevel: null,
            batteryCharging: null,
            cpuCores: null,
            screenWidth: null,
            screenHeight: null,
            pageLatency: null
        },
        thresholds: {
            latency: null,
            networkQuality: null
        },
        batteryCheckInterval: null
    };

    // Éléments DOM (seront initialisés après le chargement du DOM)
    let elements = {};

    // ========== INITIALISATION ==========
    function init() {
        console.log('NavDash - Initialisation du diagnostic...');
        
        // Initialiser les éléments DOM
        elements = {
            // Métriques
            networkSpeed: document.querySelector('[data-cy="display-network-speed"]'),
            batteryLevel: document.querySelector('[data-cy="display-battery-level"]'),
            batteryStatus: document.querySelector('[data-cy="display-battery-status"]'),
            cpuCores: document.querySelector('[data-cy="display-cpu-cores"]'),
            screenResolution: document.querySelector('[data-cy="display-screen-resolution"]'),
            pageLatency: document.querySelector('[data-cy="display-page-latency"]'),
            
            // Alertes et messages
            latencyAlert: document.getElementById('latencyAlert'),
            latencyAlertMessage: document.getElementById('latencyAlertMessage'),
            formDisabledBattery: document.querySelector('[data-cy="msg-form-disabled-battery"]'),
            formDisabledMobile: document.querySelector('[data-cy="msg-form-disabled-mobile"]'),
            
            // Formulaire
            profileForm: document.getElementById('profileForm'),
            latencyThresholdInput: document.getElementById('latencyThreshold'),
            networkQualityThresholdInput: document.getElementById('networkQualityThreshold'),
            slowNetworkReasonGroup: document.getElementById('slowNetworkReasonGroup'),
            slowNetworkReasonTextarea: document.getElementById('slowNetworkReason')
        };
        
        // Charger les préférences depuis Local Storage
        loadUserPreferences();
        
        // Initialiser les métriques
        initCPUCores();
        initScreenResolution();
        initPageLatency();
        initNetworkSpeed();
        initBatteryStatus();
        
        // Configurer les événements
        setupEventListeners();
        
        // Vérifier les conditions initiales
        checkAllConditions();
        
        // Lancer les mises à jour périodiques
        setupPeriodicUpdates();
        
        console.log('NavDash - Initialisation terminée');
    }

    // ========== CHARGEMENT DES PRÉFÉRENCES ==========
    function loadUserPreferences() {
        try {
            const savedProfile = localStorage.getItem(LOCAL_STORAGE_KEY);
            if (savedProfile) {
                const profile = JSON.parse(savedProfile);
                
                // Charger les seuils
                if (profile.latencyThreshold) {
                    state.thresholds.latency = parseInt(profile.latencyThreshold);
                    if (elements.latencyThresholdInput) {
                        elements.latencyThresholdInput.value = profile.latencyThreshold;
                    }
                }
                
                if (profile.networkQualityThreshold) {
                    state.thresholds.networkQuality = profile.networkQualityThreshold;
                    if (elements.networkQualityThresholdInput) {
                        elements.networkQualityThresholdInput.value = profile.networkQualityThreshold;
                    }
                }
                
                // Charger les autres champs du formulaire
                const fieldMappings = {
                    'lastName': 'lastName',
                    'firstName': 'firstName',
                    'email': 'email',
                    'subscriptionType': 'subscriptionType'
                };
                
                Object.keys(fieldMappings).forEach(function(key) {
                    if (profile[key]) {
                        const element = document.getElementById(key);
                        if (element) {
                            element.value = profile[key];
                        }
                    }
                });
                
                console.log('Préférences chargées depuis Local Storage:', profile);
            }
        } catch (error) {
            console.error('Erreur lors du chargement des préférences:', error);
        }
    }

    // ========== SAUVEGARDE DES PRÉFÉRENCES ==========
    function saveUserPreferences() {
        try {
            const profile = {
                lastName: document.getElementById('lastName')?.value || '',
                firstName: document.getElementById('firstName')?.value || '',
                email: document.getElementById('email')?.value || '',
                subscriptionType: document.getElementById('subscriptionType')?.value || '',
                latencyThreshold: parseInt(elements.latencyThresholdInput?.value) || null,
                networkQualityThreshold: elements.networkQualityThresholdInput?.value || ''
            };
            
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(profile));
            
            // Mettre à jour les seuils dans l'état
            state.thresholds.latency = profile.latencyThreshold;
            state.thresholds.networkQuality = profile.networkQualityThreshold;
            
            console.log('Préférences sauvegardées dans Local Storage:', profile);
        } catch (error) {
            console.error('Erreur lors de la sauvegarde des préférences:', error);
        }
    }

    // ========== MÉTRIQUES : CŒURS CPU ==========
    function initCPUCores() {
        const cores = navigator.hardwareConcurrency || 'Non disponible';
        state.metrics.cpuCores = cores;
        
        if (elements.cpuCores) {
            elements.cpuCores.textContent = cores;
        }
        
        console.log('Cœurs CPU:', cores);
    }

    // ========== MÉTRIQUES : RÉSOLUTION D'ÉCRAN ==========
    function initScreenResolution() {
        updateScreenResolution();
        window.addEventListener('resize', updateScreenResolution);
    }

    function updateScreenResolution() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        
        state.metrics.screenWidth = width;
        state.metrics.screenHeight = height;
        
        if (elements.screenResolution) {
            elements.screenResolution.textContent = width + ' x ' + height;
        }
        
        // Vérifier la condition de désactivation du formulaire
        checkFormDisableConditions();
    }

    // ========== MÉTRIQUES : LATENCE DE CHARGEMENT ==========
    function initPageLatency() {
        // Attendre que le chargement soit complètement terminé
        if (document.readyState === 'complete') {
            calculateAndDisplayLatency();
        } else {
            window.addEventListener('load', calculateAndDisplayLatency);
        }
    }

    function calculateAndDisplayLatency() {
        try {
            // Essayer d'abord l'API moderne PerformanceNavigationTiming
            if (window.performance && window.performance.getEntriesByType) {
                const navigationEntries = window.performance.getEntriesByType('navigation');
                if (navigationEntries && navigationEntries.length > 0) {
                    const navTiming = navigationEntries[0];
                    const loadTime = Math.round(navTiming.domContentLoadedEventEnd - navTiming.fetchStart);
                    
                    if (loadTime > 0 && loadTime < 60000) { // Validation: entre 0 et 60 secondes
                        state.metrics.pageLatency = loadTime;
                        
                        if (elements.pageLatency) {
                            elements.pageLatency.textContent = loadTime + ' ms';
                        }
                        
                        console.log('Latence de chargement (API moderne):', loadTime, 'ms');
                        checkLatencyAlert();
                        return;
                    }
                }
            }
            
            // Fallback sur l'ancienne API Performance Timing
            if (window.performance && window.performance.timing) {
                const timing = window.performance.timing;
                
                // Vérifier que les valeurs sont disponibles
                if (timing.domContentLoadedEventEnd > 0 && timing.navigationStart > 0) {
                    const loadTime = timing.domContentLoadedEventEnd - timing.navigationStart;
                    
                    // Validation: la latence doit être positive et raisonnable (< 60 secondes)
                    if (loadTime > 0 && loadTime < 60000) {
                        state.metrics.pageLatency = loadTime;
                        
                        if (elements.pageLatency) {
                            elements.pageLatency.textContent = loadTime + ' ms';
                        }
                        
                        console.log('Latence de chargement:', loadTime, 'ms');
                        checkLatencyAlert();
                        return;
                    }
                }
            }
            
            // Si aucune méthode n'a fonctionné
            if (elements.pageLatency) {
                elements.pageLatency.textContent = 'Non mesurable';
            }
            console.warn('Impossible de calculer la latence de chargement');
            
        } catch (error) {
            console.error('Erreur lors du calcul de la latence:', error);
            if (elements.pageLatency) {
                elements.pageLatency.textContent = 'Erreur';
            }
        }
    }

    // ========== MÉTRIQUES : VITESSE RÉSEAU ==========
    function initNetworkSpeed() {
        if (navigator.connection || navigator.mozConnection || navigator.webkitConnection) {
            const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
            updateNetworkSpeed(connection);
            
            // Écouter les changements
            connection.addEventListener('change', function() {
                updateNetworkSpeed(connection);
            });
        } else {
            if (elements.networkSpeed) {
                elements.networkSpeed.textContent = 'Non supporté';
            }
            console.warn('Network Information API non supportée sur ce navigateur');
        }
    }

    function updateNetworkSpeed(connection) {
        const effectiveType = connection.effectiveType || 'inconnu';
        state.metrics.networkSpeed = effectiveType;
        
        if (elements.networkSpeed) {
            elements.networkSpeed.textContent = effectiveType.toUpperCase();
        }
        
        console.log('Vitesse réseau mise à jour:', effectiveType);
        
        // Vérifier la condition du champ conditionnel
        checkSlowNetworkCondition();
    }

    // ========== MÉTRIQUES : BATTERIE ==========
    function initBatteryStatus() {
        if (navigator.getBattery) {
            navigator.getBattery().then(function(battery) {
                // Mise à jour initiale
                updateBatteryStatus(battery);
                
                // Configurer les événements de changement
                battery.addEventListener('levelchange', function() {
                    updateBatteryStatus(battery);
                });
                
                battery.addEventListener('chargingchange', function() {
                    updateBatteryStatus(battery);
                });
                
                // Mise à jour périodique toutes les 10 secondes
                state.batteryCheckInterval = setInterval(function() {
                    updateBatteryStatus(battery);
                }, BATTERY_UPDATE_INTERVAL);
                
            }).catch(function(error) {
                console.error('Erreur lors de l\'accès à l\'API Batterie:', error);
                displayBatteryNotSupported();
            });
        } else {
            displayBatteryNotSupported();
        }
    }

    function updateBatteryStatus(battery) {
        const level = Math.round(battery.level * 100);
        const charging = battery.charging;
        const chargingText = charging ? 'Branché' : 'Débranché';
        
        state.metrics.batteryLevel = level;
        state.metrics.batteryCharging = charging;
        
        if (elements.batteryLevel) {
            elements.batteryLevel.textContent = level;
        }
        
        if (elements.batteryStatus) {
            elements.batteryStatus.textContent = chargingText;
        }
        
        console.log('Batterie mise à jour:', level + '%', chargingText);
        
        // Vérifier la condition de désactivation du formulaire
        checkFormDisableConditions();
    }

    function displayBatteryNotSupported() {
        if (elements.batteryLevel) {
            elements.batteryLevel.textContent = 'Non supporté';
        }
        if (elements.batteryStatus) {
            elements.batteryStatus.textContent = '';
        }
        console.warn('Battery Status API non supportée (typique sur Safari)');
    }

    // ========== LOGIQUE CONDITIONNELLE : ALERTE LATENCE ==========
    function checkLatencyAlert() {
        if (!elements.latencyAlert || !elements.latencyAlertMessage) {
            return;
        }
        
        if (state.thresholds.latency && 
            state.metrics.pageLatency && 
            state.metrics.pageLatency > state.thresholds.latency) {
            
            const message = '⚠️ ALERTE : La latence de chargement (' + 
                          state.metrics.pageLatency + 
                          ' ms) dépasse votre seuil de ' + 
                          state.thresholds.latency + ' ms';
            
            elements.latencyAlertMessage.textContent = message;
            elements.latencyAlert.classList.remove('hidden');
            
            console.log('Alerte latence déclenchée');
        } else {
            elements.latencyAlert.classList.add('hidden');
        }
    }

    // ========== LOGIQUE CONDITIONNELLE : CHAMP MOTIF LENTEUR ==========
    function checkSlowNetworkCondition() {
        if (!elements.slowNetworkReasonGroup || !elements.slowNetworkReasonTextarea) {
            return;
        }
        
        // Vérifier si les deux valeurs nécessaires sont disponibles
        if (!state.thresholds.networkQuality || !state.metrics.networkSpeed) {
            elements.slowNetworkReasonGroup.classList.add('hidden');
            elements.slowNetworkReasonTextarea.removeAttribute('required');
            return;
        }
        
        const currentNetwork = state.metrics.networkSpeed.toLowerCase();
        const thresholdNetwork = state.thresholds.networkQuality.toLowerCase();
        
        const currentIndex = NETWORK_QUALITY_ORDER[currentNetwork];
        const thresholdIndex = NETWORK_QUALITY_ORDER[thresholdNetwork];
        
        // Si l'index actuel est >= à l'index du seuil, la connexion est pire ou égale
        if (currentIndex !== undefined && 
            thresholdIndex !== undefined && 
            currentIndex >= thresholdIndex) {
            
            elements.slowNetworkReasonGroup.classList.remove('hidden');
            elements.slowNetworkReasonTextarea.setAttribute('required', 'required');
            
            console.log('Champ "Motif de la Lenteur" affiché (réseau actuel: ' + 
                       currentNetwork + ' <= seuil: ' + thresholdNetwork + ')');
        } else {
            elements.slowNetworkReasonGroup.classList.add('hidden');
            elements.slowNetworkReasonTextarea.removeAttribute('required');
        }
    }

    // ========== LOGIQUE CONDITIONNELLE : DÉSACTIVATION FORMULAIRE ==========
    function checkFormDisableConditions() {
        if (!elements.profileForm) {
            return;
        }
        
        let shouldDisable = false;
        
        // Condition 1: Batterie < 10% ET non branchée
        const batteryCritical = state.metrics.batteryLevel !== null && 
                               state.metrics.batteryLevel < 10 && 
                               !state.metrics.batteryCharging;
        
        if (batteryCritical) {
            if (elements.formDisabledBattery) {
                elements.formDisabledBattery.classList.remove('hidden');
            }
            shouldDisable = true;
            console.log('Formulaire désactivé: batterie critique (<10% et non branché)');
        } else {
            if (elements.formDisabledBattery) {
                elements.formDisabledBattery.classList.add('hidden');
            }
        }
        
        // Condition 2: Largeur viewport < 768px
        const isMobile = state.metrics.screenWidth !== null && 
                        state.metrics.screenWidth < 768;
        
        if (isMobile) {
            if (elements.formDisabledMobile) {
                elements.formDisabledMobile.classList.remove('hidden');
            }
            shouldDisable = true;
            console.log('Formulaire désactivé: mode mobile (viewport < 768px)');
        } else {
            if (elements.formDisabledMobile) {
                elements.formDisabledMobile.classList.add('hidden');
            }
        }
        
        // Appliquer la désactivation
        disableFormElements(shouldDisable);
    }

    function disableFormElements(disable) {
        const formElements = elements.profileForm.querySelectorAll('input, select, textarea, button');
        
        formElements.forEach(function(element) {
            if (disable) {
                element.setAttribute('disabled', 'disabled');
            } else {
                element.removeAttribute('disabled');
            }
        });
    }

    // ========== VÉRIFICATION DE TOUTES LES CONDITIONS ==========
    function checkAllConditions() {
        checkLatencyAlert();
        checkSlowNetworkCondition();
        checkFormDisableConditions();
    }

    // ========== ÉVÉNEMENTS ==========
    function setupEventListeners() {
        // Écouter les changements de seuils
        if (elements.latencyThresholdInput) {
            elements.latencyThresholdInput.addEventListener('change', function() {
                state.thresholds.latency = parseInt(this.value) || null;
                checkLatencyAlert();
                console.log('Seuil de latence mis à jour:', state.thresholds.latency);
            });
            
            elements.latencyThresholdInput.addEventListener('input', function() {
                state.thresholds.latency = parseInt(this.value) || null;
                checkLatencyAlert();
            });
        }
        
        if (elements.networkQualityThresholdInput) {
            elements.networkQualityThresholdInput.addEventListener('change', function() {
                state.thresholds.networkQuality = this.value;
                checkSlowNetworkCondition();
                console.log('Seuil de qualité réseau mis à jour:', state.thresholds.networkQuality);
            });
        }
        
        // Sauvegarder les préférences lors de la soumission du formulaire
        if (elements.profileForm) {
            elements.profileForm.addEventListener('submit', function() {
                saveUserPreferences();
            });
        }
    }

    // ========== MISES À JOUR PÉRIODIQUES ==========
    function setupPeriodicUpdates() {
        // Vérifier toutes les conditions périodiquement
        setInterval(function() {
            checkAllConditions();
        }, METRICS_CHECK_INTERVAL);
    }

    // ========== NETTOYAGE ==========
    function cleanup() {
        if (state.batteryCheckInterval) {
            clearInterval(state.batteryCheckInterval);
        }
    }

    // Nettoyer avant de quitter la page
    window.addEventListener('beforeunload', cleanup);

    // ========== LANCEMENT ==========
    // Attendre que le DOM soit complètement chargé
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        // Le DOM est déjà chargé
        init();
    }

})();
