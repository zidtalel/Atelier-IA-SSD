/**
 * NavDash Metrics Manager
 * Handles real-time metrics collection using Browser Native APIs
 */

// Constants
const NETWORK_QUALITY_ORDER = ['4g', '3g', 'slow-3g', '2g', 'slow-2g'];
const LOCAL_STORAGE_KEY = 'navdash.userProfile';
const METRICS_UPDATE_INTERVAL = 2000; // 2 seconds

// Global state
let currentMetrics = {
    networkSpeed: null,
    batteryLevel: null,
    batteryCharging: null,
    cpuCores: null,
    screenWidth: null,
    screenHeight: null,
    pageLatency: null
};

let userThresholds = {
    latencyThreshold: null,
    networkQualityThreshold: null
};

/**
 * Initialize all metrics on page load
 */
document.addEventListener('DOMContentLoaded', function() {
    console.log('NavDash Metrics - Initialisation...');
    
    // Load user preferences from Local Storage
    loadUserPreferences();
    
    // Initialize all metrics
    initCPUCores();
    initScreenResolution();
    initPageLatency();
    initNetworkSpeed();
    initBatteryStatus();
    
    // Setup form listeners
    setupFormListeners();
    
    // Setup periodic updates
    setupPeriodicUpdates();
    
    // Check form disable conditions
    checkFormDisableConditions();
});

/**
 * Load user preferences from Local Storage
 */
function loadUserPreferences() {
    try {
        const savedProfile = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (savedProfile) {
            const profile = JSON.parse(savedProfile);
            userThresholds.latencyThreshold = profile.latencyThreshold;
            userThresholds.networkQualityThreshold = profile.networkQualityThreshold;
            
            // Populate form fields
            if (profile.lastName) document.getElementById('lastName').value = profile.lastName;
            if (profile.firstName) document.getElementById('firstName').value = profile.firstName;
            if (profile.email) document.getElementById('email').value = profile.email;
            if (profile.subscriptionType) document.getElementById('subscriptionType').value = profile.subscriptionType;
            if (profile.latencyThreshold) document.getElementById('latencyThreshold').value = profile.latencyThreshold;
            if (profile.networkQualityThreshold) document.getElementById('networkQualityThreshold').value = profile.networkQualityThreshold;
            
            console.log('Préférences chargées:', profile);
        }
    } catch (error) {
        console.error('Erreur lors du chargement des préférences:', error);
    }
}

/**
 * Save user preferences to Local Storage
 */
function saveUserPreferences() {
    try {
        const profile = {
            lastName: document.getElementById('lastName').value,
            firstName: document.getElementById('firstName').value,
            email: document.getElementById('email').value,
            subscriptionType: document.getElementById('subscriptionType').value,
            latencyThreshold: parseInt(document.getElementById('latencyThreshold').value),
            networkQualityThreshold: document.getElementById('networkQualityThreshold').value
        };
        
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(profile));
        userThresholds.latencyThreshold = profile.latencyThreshold;
        userThresholds.networkQualityThreshold = profile.networkQualityThreshold;
        
        console.log('Préférences sauvegardées:', profile);
    } catch (error) {
        console.error('Erreur lors de la sauvegarde des préférences:', error);
    }
}

/**
 * Initialize CPU Cores (static value)
 */
function initCPUCores() {
    const cores = navigator.hardwareConcurrency || 'Non disponible';
    currentMetrics.cpuCores = cores;
    document.getElementById('cpuCores').textContent = cores;
    console.log('Cœurs CPU:', cores);
}

/**
 * Initialize Screen Resolution
 */
function initScreenResolution() {
    updateScreenResolution();
    // Update on window resize
    window.addEventListener('resize', updateScreenResolution);
}

function updateScreenResolution() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    currentMetrics.screenWidth = width;
    currentMetrics.screenHeight = height;
    document.getElementById('screenResolution').textContent = `${width} x ${height}`;
    
    // Check form disable conditions when screen size changes
    checkFormDisableConditions();
}

/**
 * Initialize Page Latency
 */
function initPageLatency() {
    if (performance && performance.timing) {
        const loadTime = performance.timing.domContentLoadedEventEnd - performance.timing.navigationStart;
        currentMetrics.pageLatency = loadTime;
        document.getElementById('pageLatency').textContent = `${loadTime} ms`;
        console.log('Latence de chargement:', loadTime, 'ms');
        
        // Check latency alert
        checkLatencyAlert();
    } else {
        document.getElementById('pageLatency').textContent = 'Non disponible';
    }
}

/**
 * Initialize Network Speed
 */
function initNetworkSpeed() {
    if (navigator.connection) {
        updateNetworkSpeed();
        // Listen for changes
        navigator.connection.addEventListener('change', updateNetworkSpeed);
    } else {
        document.getElementById('networkSpeed').textContent = 'Non supporté';
        console.warn('Network Information API non supportée');
    }
}

function updateNetworkSpeed() {
    const connection = navigator.connection;
    const effectiveType = connection.effectiveType || 'Inconnu';
    currentMetrics.networkSpeed = effectiveType;
    document.getElementById('networkSpeed').textContent = effectiveType.toUpperCase();
    console.log('Vitesse réseau:', effectiveType);
    
    // Check conditional field for slow network
    checkSlowNetworkField();
}

/**
 * Initialize Battery Status
 */
function initBatteryStatus() {
    if (navigator.getBattery) {
        navigator.getBattery().then(function(battery) {
            updateBatteryStatus(battery);
            
            // Listen for battery changes
            battery.addEventListener('levelchange', function() {
                updateBatteryStatus(battery);
            });
            battery.addEventListener('chargingchange', function() {
                updateBatteryStatus(battery);
            });
        });
    } else {
        document.getElementById('batteryLevel').textContent = 'Non supporté';
        document.getElementById('batteryStatus').textContent = '';
        console.warn('Battery Status API non supportée (Safari)');
    }
}

function updateBatteryStatus(battery) {
    const level = Math.round(battery.level * 100);
    const charging = battery.charging ? 'Branché' : 'Débranché';
    
    currentMetrics.batteryLevel = level;
    currentMetrics.batteryCharging = battery.charging;
    
    document.getElementById('batteryLevel').textContent = level;
    document.getElementById('batteryStatus').textContent = charging;
    console.log('Batterie:', level + '%', charging);
    
    // Check form disable conditions
    checkFormDisableConditions();
}

/**
 * Check if latency alert should be displayed
 */
function checkLatencyAlert() {
    const alertDiv = document.getElementById('latencyAlert');
    const messageSpan = document.getElementById('latencyAlertMessage');
    
    if (userThresholds.latencyThreshold && currentMetrics.pageLatency > userThresholds.latencyThreshold) {
        messageSpan.textContent = `⚠️ ALERTE : La latence de chargement (${currentMetrics.pageLatency} ms) dépasse votre seuil de ${userThresholds.latencyThreshold} ms`;
        alertDiv.classList.remove('hidden');
    } else {
        alertDiv.classList.add('hidden');
    }
}

/**
 * Check if slow network reason field should be displayed
 */
function checkSlowNetworkField() {
    const reasonGroup = document.getElementById('slowNetworkReasonGroup');
    const reasonField = document.getElementById('slowNetworkReason');
    
    if (!userThresholds.networkQualityThreshold || !currentMetrics.networkSpeed) {
        reasonGroup.classList.add('hidden');
        reasonField.removeAttribute('required');
        return;
    }
    
    const currentIndex = NETWORK_QUALITY_ORDER.indexOf(currentMetrics.networkSpeed.toLowerCase());
    const thresholdIndex = NETWORK_QUALITY_ORDER.indexOf(userThresholds.networkQualityThreshold.toLowerCase());
    
    // Show field if current network is worse than or equal to threshold
    if (currentIndex >= thresholdIndex) {
        reasonGroup.classList.remove('hidden');
        reasonField.setAttribute('required', 'required');
        console.log('Champ "Motif de la Lenteur" affiché (réseau lent)');
    } else {
        reasonGroup.classList.add('hidden');
        reasonField.removeAttribute('required');
    }
}

/**
 * Check if form should be disabled
 */
function checkFormDisableConditions() {
    const form = document.getElementById('profileForm');
    const batteryWarning = document.getElementById('formDisabledBattery');
    const mobileWarning = document.getElementById('formDisabledMobile');
    
    let shouldDisable = false;
    
    // Condition 1: Battery < 10% and not charging
    if (currentMetrics.batteryLevel !== null && 
        currentMetrics.batteryLevel < 10 && 
        !currentMetrics.batteryCharging) {
        batteryWarning.classList.remove('hidden');
        shouldDisable = true;
        console.log('Formulaire désactivé: batterie critique');
    } else {
        batteryWarning.classList.add('hidden');
    }
    
    // Condition 2: Screen width < 768px
    if (currentMetrics.screenWidth !== null && currentMetrics.screenWidth < 768) {
        mobileWarning.classList.remove('hidden');
        shouldDisable = true;
        console.log('Formulaire désactivé: mode mobile');
    } else {
        mobileWarning.classList.add('hidden');
    }
    
    // Disable/enable form
    const formElements = form.querySelectorAll('input, select, textarea, button');
    formElements.forEach(function(element) {
        if (shouldDisable) {
            element.setAttribute('disabled', 'disabled');
        } else {
            element.removeAttribute('disabled');
        }
    });
}

/**
 * Setup form listeners
 */
function setupFormListeners() {
    const form = document.getElementById('profileForm');
    
    // Listen for threshold changes
    document.getElementById('latencyThreshold').addEventListener('change', function() {
        userThresholds.latencyThreshold = parseInt(this.value);
        checkLatencyAlert();
    });
    
    document.getElementById('networkQualityThreshold').addEventListener('change', function() {
        userThresholds.networkQualityThreshold = this.value;
        checkSlowNetworkField();
    });
    
    // Save to Local Storage on form submit
    form.addEventListener('submit', function() {
        saveUserPreferences();
    });
}

/**
 * Setup periodic updates for metrics that may change
 */
function setupPeriodicUpdates() {
    setInterval(function() {
        // Re-check conditions periodically
        checkLatencyAlert();
        checkSlowNetworkField();
        checkFormDisableConditions();
    }, METRICS_UPDATE_INTERVAL);
}
