package com.bdeb.navdash.controller;

import com.bdeb.navdash.dto.UserProfileDTO;
import com.bdeb.navdash.service.UserProfileService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

/**
 * Controller for the main dashboard
 * Handles the display of metrics and user profile form
 */
@Controller
public class DashboardController {

    private static final Logger logger = LoggerFactory.getLogger(DashboardController.class);

    @Autowired
    private UserProfileService userProfileService;

    /**
     * Display the main dashboard page
     * 
     * @param model Spring MVC model
     * @return The dashboard view name
     */
    @GetMapping("/")
    public String showDashboard(Model model) {
        logger.info("Accès à la page dashboard");

        // Add an empty UserProfileDTO for the form
        if (!model.containsAttribute("userProfile")) {
            model.addAttribute("userProfile", new UserProfileDTO());
        }

        return "dashboard";
    }

    /**
     * Handle form submission for user profile
     * 
     * @param userProfile        The submitted user profile data
     * @param bindingResult      Validation results
     * @param model              Spring MVC model
     * @param redirectAttributes Attributes for redirect
     * @return Redirect to dashboard or return to form
     */
    @PostMapping("/profile/save")
    public String saveProfile(@Valid @ModelAttribute("userProfile") UserProfileDTO userProfile,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {

        logger.debug("Tentative de sauvegarde du profil: {}", userProfile);

        // Check for validation errors
        if (bindingResult.hasErrors()) {
            logger.warn("Erreurs de validation du formulaire: {}", bindingResult.getAllErrors());
            model.addAttribute("errorMessage", "Veuillez corriger les erreurs du formulaire");
            return "dashboard";
        }

        // Additional business validation
        if (!userProfileService.validate(userProfile)) {
            logger.warn("Validation métier échouée pour le profil");
            model.addAttribute("errorMessage", "Erreur de validation des données");
            return "dashboard";
        }

        // Save the profile
        try {
            userProfileService.save(userProfile);
            logger.info("Profil sauvegardé avec succès pour: {}", userProfile.getEmail());
            redirectAttributes.addFlashAttribute("successMessage",
                    "Profil enregistré avec succès !");
        } catch (Exception e) {
            logger.error("Erreur lors de la sauvegarde du profil", e);
            model.addAttribute("errorMessage",
                    "Erreur lors de l'enregistrement du profil");
            return "dashboard";
        }

        return "redirect:/";
    }
}
