package com.bdeb.navdash.service;

import com.bdeb.navdash.dto.UserProfileDTO;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Implementation of UserProfileService
 * Handles user profile management and validation
 */
@Service
public class UserProfileServiceImpl implements UserProfileService {

    private static final Logger logger = LoggerFactory.getLogger(UserProfileServiceImpl.class);
    private final Gson gson = new Gson();

    @Override
    public UserProfileDTO save(UserProfileDTO userProfile) {
        logger.info("Sauvegarde du profil utilisateur pour: {} {}", 
                   userProfile.getFirstName(), userProfile.getLastName());
        
        // Serialize to JSON for logging purposes
        String jsonProfile = gson.toJson(userProfile);
        logger.debug("Profil sérialisé: {}", jsonProfile);
        
        // In a real application, this would persist to a database
        // For now, we just return the profile as-is
        // The actual persistence is handled by Local Storage on the client side
        
        logger.info("Profil sauvegardé avec succès pour l'email: {}", userProfile.getEmail());
        return userProfile;
    }

    @Override
    public boolean validate(UserProfileDTO userProfile) {
        logger.debug("Validation du profil utilisateur: {}", userProfile.getEmail());
        
        if (userProfile == null) {
            logger.warn("Tentative de validation d'un profil null");
            return false;
        }
        
        // Basic validation checks (additional to Bean Validation annotations)
        boolean isValid = userProfile.getEmail() != null && 
                         !userProfile.getEmail().trim().isEmpty() &&
                         userProfile.getLatencyThreshold() != null &&
                         userProfile.getLatencyThreshold() >= 100 &&
                         userProfile.getLatencyThreshold() <= 5000;
        
        if (!isValid) {
            logger.warn("Validation échouée pour le profil: {}", userProfile);
        } else {
            logger.debug("Profil validé avec succès");
        }
        
        return isValid;
    }
}
