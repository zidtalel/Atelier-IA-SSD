package com.bdeb.navdash.service;

import com.bdeb.navdash.dto.UserProfileDTO;

/**
 * Service interface for User Profile management
 */
public interface UserProfileService {

    /**
     * Saves user profile preferences
     * 
     * @param userProfile The user profile data
     * @return The saved user profile
     */
    UserProfileDTO save(UserProfileDTO userProfile);

    /**
     * Validates the user profile data
     * 
     * @param userProfile The user profile to validate
     * @return true if valid, false otherwise
     */
    boolean validate(UserProfileDTO userProfile);
}
