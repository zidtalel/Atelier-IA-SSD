package com.bdeb.navdash.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Data Transfer Object for User Profile (Diagnostic Profile Form)
 */
public class UserProfileDTO {

    @NotBlank(message = "Le nom est obligatoire")
    @Size(max = 50, message = "Le nom ne peut pas dépasser 50 caractères")
    private String lastName;

    @NotBlank(message = "Le prénom est obligatoire")
    @Size(max = 50, message = "Le prénom ne peut pas dépasser 50 caractères")
    private String firstName;

    @NotBlank(message = "L'email est obligatoire")
    @Email(message = "Format d'email invalide")
    private String email;

    @NotBlank(message = "Le type d'abonnement est obligatoire")
    private String subscriptionType;

    @NotNull(message = "Le seuil de latence est obligatoire")
    @Min(value = 100, message = "Le seuil doit être entre 100 et 5000 ms")
    @Max(value = 5000, message = "Le seuil doit être entre 100 et 5000 ms")
    private Integer latencyThreshold;

    @NotBlank(message = "Le seuil de qualité réseau est obligatoire")
    private String networkQualityThreshold;

    @Size(max = 500, message = "Le motif ne peut pas dépasser 500 caractères")
    private String slowNetworkReason;

    // Constructors
    public UserProfileDTO() {
    }

    public UserProfileDTO(String lastName, String firstName, String email,
            String subscriptionType, Integer latencyThreshold,
            String networkQualityThreshold) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.email = email;
        this.subscriptionType = subscriptionType;
        this.latencyThreshold = latencyThreshold;
        this.networkQualityThreshold = networkQualityThreshold;
    }

    // Getters and Setters
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSubscriptionType() {
        return subscriptionType;
    }

    public void setSubscriptionType(String subscriptionType) {
        this.subscriptionType = subscriptionType;
    }

    public Integer getLatencyThreshold() {
        return latencyThreshold;
    }

    public void setLatencyThreshold(Integer latencyThreshold) {
        this.latencyThreshold = latencyThreshold;
    }

    public String getNetworkQualityThreshold() {
        return networkQualityThreshold;
    }

    public void setNetworkQualityThreshold(String networkQualityThreshold) {
        this.networkQualityThreshold = networkQualityThreshold;
    }

    public String getSlowNetworkReason() {
        return slowNetworkReason;
    }

    public void setSlowNetworkReason(String slowNetworkReason) {
        this.slowNetworkReason = slowNetworkReason;
    }

    @Override
    public String toString() {
        return "UserProfileDTO{" +
                "lastName='" + lastName + '\'' +
                ", firstName='" + firstName + '\'' +
                ", email='" + email + '\'' +
                ", subscriptionType='" + subscriptionType + '\'' +
                ", latencyThreshold=" + latencyThreshold +
                ", networkQualityThreshold='" + networkQualityThreshold + '\'' +
                '}';
    }
}
